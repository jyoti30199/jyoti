package com.perform;

import java.io.IOException;
import java.security.SecureRandom;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/PasswordGeneratorServlet")
public class PasswordGeneratorServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private static final String CHAR_LOWER = "abcdefghijklmnopqrstuvwxyz";
    private static final String CHAR_UPPER = CHAR_LOWER.toUpperCase();
    private static final String NUMBER = "0123456789";
    private static final String OTHER_CHAR = "!@#$%&*_+-=[]?";
    private static final String PASSWORD_ALLOW_BASE = CHAR_LOWER + CHAR_UPPER + NUMBER + OTHER_CHAR;
    private static final SecureRandom random = new SecureRandom();
    private static final int MIN_LENGTH = 8;
    private static final int MAX_LENGTH = 20;

    public PasswordGeneratorServlet() {
        super();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.getWriter().append("Served at: ").append(request.getContextPath());
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int requestedLength = Integer.parseInt(request.getParameter("length"));

        // Check if the requested length is within the allowed range
        if (requestedLength < MIN_LENGTH || requestedLength > MAX_LENGTH) {
            request.setAttribute("error", "Password length must be between " + MIN_LENGTH + " to " + MAX_LENGTH + " characters.");
            request.getRequestDispatcher("error.jsp").forward(request, response);
            return;
        }

        // Generate the password
        String password = generatePassword(requestedLength);
        request.setAttribute("password", password);
        request.getRequestDispatcher("result.jsp").forward(request, response);
    }

    private String generatePassword(int length) {
        StringBuilder password = new StringBuilder(length);
        for (int i = 0; i < length; i++) {
            int randomIndex = random.nextInt(PASSWORD_ALLOW_BASE.length());
            password.append(PASSWORD_ALLOW_BASE.charAt(randomIndex));
        }
        return password.toString();
    }
}
