import java.util.*;

import org.hibernate.*;
import org.hibernate.cfg.*;

public class part
{
	public static void main(String args[])throws Exception
	{
		int i;
		Scanner sc=new Scanner(System.in); 
		Configuration cfg=new Configuration();
		SessionFactory sf=cfg.configure().buildSessionFactory();
		Session ss=sf.openSession();
		mypojo pojo=new mypojo();
		
		

		System.out.println("press 1 to see record");
		System.out.println("press 2 to update");
		System.out.println("press 3 to delete");
		System.out.println("press 4 to insert a data");
		System.out.println("enter your choice");
		while(true)
		{		
		i=sc.nextInt();
		
		switch(i)
		{
		case 1:
		{
			Transaction tx1=ss.beginTransaction();
			System.out.println("how many data u  want to see");
			int a=sc.nextInt();
		Query q=ss.createQuery("from mypojo");	
		q.setFirstResult(0);  
		q.setMaxResults(a);  
		List list=q.list();//will return the records 
		System.out.println(list);
		
		List stud=q.list();
		Iterator it=stud.iterator();
		while(it.hasNext())
		{
			pojo=(mypojo)it.next();
			System.out.println(pojo.getEmpno());
			System.out.println(pojo.getName());
			System.out.println(pojo.getPhoneno());
			System.out.println(pojo.getAddress());
			 
		
		}
		tx1.commit();
		}
	    break;	
		case 2:
		{   
			Transaction tx1=ss.beginTransaction();
			System.out.println("enter the ID u want to update");
			String d=sc.next();		
			System.out.println("enter name,phoneno,address");
			String a=sc.next();
			String b=sc.next();
			String c=sc.next();
			
		Query q2=ss.createQuery("update mypojo set name=:n,phoneno=:m,address=:v where empno=:i"); 
		//we use pojo class name not the table name
		q2.setParameter("n",a); 
		q2.setParameter("m",b);
		q2.setParameter("v",c); 
		q2.setParameter("i",d);  
		  
		int status=q2.executeUpdate();  
		System.out.println(status+"the row is updated");  
		tx1.commit();
		
		}
		break;
		case 3:
		{
			Transaction tx1=ss.beginTransaction();
			System.out.println("Enter the Id u want to delete");
			String a=sc.next();
		Query q3=ss.createQuery("delete from mypojo where empno=:n ");  
		//specifying class name (mypojo) not tablename  

		q3.setParameter("n",a); 
		int status1=q3.executeUpdate();
		System.out.println(status1+"the row is deleted");  
		tx1.commit();
		
		}
		break;
		case 4:
		{
			Transaction tx2=ss.beginTransaction();
		Query q4=ss.createQuery("select count(rollno) from mypojo");  
		System.out.println(q4);
		System.out.println("enter your employee no,name,phoneno,address");
		String a=sc.next();
		String b=sc.next();
		String c=sc.next();
		String d=sc.next();
		pojo.setEmpno(a);
		pojo.setName(b);
		pojo.setPhoneno(c);
		pojo.setAddress(d);
		ss.save(pojo);//data will be saved into the database

		System.out.println("data save sucessfully");
	     tx2.commit();
		}
		break;
		}
		
		
	}
		
	
		
		
}
}



